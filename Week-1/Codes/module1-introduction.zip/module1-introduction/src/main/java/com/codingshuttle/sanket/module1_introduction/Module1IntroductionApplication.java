package com.codingshuttle.sanket.module1_introduction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Module1IntroductionApplication {

	public static void main(String[] args) {
		SpringApplication.run(Module1IntroductionApplication.class, args);
	}

}
