package com.codingshuttle.sanket.module1_introduction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Module1IntroductionApplicationTests {

	@Test
	void contextLoads() {
	}

}
